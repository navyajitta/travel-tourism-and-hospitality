use SDP;
create table Guide(guide_ID int,Name char(50),Branch char(50),City char(50),State char(50),Country char(50),Mobile_number long,Email_Address varchar(50));
desc Guide;
insert into Guide values(1,'Abhi','Tourist','Hyderabad','Telengana','India',9816667771,'abhi@123.com');
insert into Guide values(2,'Nikhil','Tourist','Chennai','Tamil Nadu','India',9893337771,'nikhil@gmail.com');
insert into Guide values(3,'Kiran','Tourist','Vijayawada','Andhra Pradesh','India',6022667771,'kiran@gmail.com');
insert into Guide values(4,'Shyam','Tourist','Vizag','Andhra Pradesh','India',7486667001,'shyam@yahoo.com');
select * from Guide;