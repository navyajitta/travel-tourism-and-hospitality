use sdp;
create table Hotels;
desc Hotels;