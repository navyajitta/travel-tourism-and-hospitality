import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {

    constructor(private auth: AuthService) {}
     registerUserData={
       "username":"",
       "email":"",
       "password":""
     }
    
  ngOnInit() { }
  registerUser() {​​
    this.auth.registerUser(this.registerUserData)
      .subscribe(
        res => {​
          console.log(this.registerUserData);
          window.alert("sucessfully registered");
        }​​,
        err => console.log(err)
      )
      }}​​