import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {

  loginUserData={
    "email":"",
    "password":""

  }
  constructor(private auth: AuthService) { }

  ngOnInit(){ }

  loginUser() {​​
   
    
    this.auth.loginUser(this.loginUserData)
      .subscribe(
        res => {
          console.log(this.loginUserData);
        window.alert("sucessfully logged in");
      },
        err => {
          console.log(err);
          window.alert("ERROR!!   verify your credentials");
        },
        
      )
    }

}