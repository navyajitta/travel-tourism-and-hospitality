def tourism():
    sum=0
    print("Hello")
    print("Welcome to Star Tours")
    print("let me make registration for you mam/sir")
    print("What is you name mam/sir")
    name=input()
    print("where are you from mam/sir ",name)
    add=input()
    print("please enter your mobile number mam/sir")
    mobileno=input()
    print("Let me tell you the available trips")
    print("Do you enjoy warm or cool climate")
    cli=input()
    if cli=="warm" or cli=="1":
        print("You con choose these places:\n1.Rajastan\n2.nagpur\n3.bilaspur")
        place=input()
        if place=="Rajastan" or place=="1":
            print("which mode of travelling you prefer:\n1.bus\n2.train")
            mode=input()
            if mode=="bus" or mode=="1":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                bus=input()
                if bus=="Ac" or bus=="1":
                    sum=sum+22000
                if bus=="Non Ac" or bus=="2":
                    sum=sum+15980
            if mode=="train" or mode=="2":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                train=input()
                if train=="Ac" or train=="1":
                    sum=sum+25000
                if train=="Non Ac" or train=="2":
                    sum=sum+16980
        if place=="nagpur" or place=="3":
            print("which mode of travelling you prefer:\n1.bus\n2.train")
            mode=input()
            if mode=="bus" or mode=="1":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                bus=input()
                if bus=="Ac" or bus=="1":
                    sum=sum+20000
                if bus=="Non Ac" or bus=="2":
                    sum=sum+15900
            if mode=="train" or mode=="2":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                train=input()
                if train=="Ac" or train=="1":
                    sum=sum+23000
                if train=="Non Ac" or train=="2":
                    sum=sum+17080
        if place=="bilaspur" or place=="3":
            print("which mode of travelling you prefer:\n1.bus\n2.train")
            mode=input()
            if mode=="bus" or mode=="1":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                bus=input()
                if bus=="Ac" or bus=="1":
                    sum=sum+14000
                if bus=="Non Ac" or bus=="2":
                    sum=sum+12,000
            if mode=="train" or mode=="2":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                train=input()
                if train=="Ac" or train=="1":
                    sum=sum+16000
                if train=="Non Ac" or train=="2":
                    sum=sum+10,000
    if cli=="cool" or cli=="2":
        print("You con choose these places:\n1.Goa\n2.OOty\n3.shimla")
        place=input()
        if place=="Goa" or place=="1":
            print("which mode of travelling you prefer:\n1.bus\n2.train")
            mode=input()
            if mode=="bus" or mode=="1":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                bus=input()
                if bus=="Ac" or bus=="1":
                    sum=sum+25000
                if bus=="Non Ac" or bus=="2":
                    sum=sum+18980
            if mode=="train" or mode=="2":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                train=input()
                if train=="Ac" or train=="1":
                    sum=sum+28000
                if train=="Non Ac" or train=="2":
                    sum=sum+22980
        if place=="Ooty" or place=="2":
            print("which mode of travelling you prefer\n1.bus\n2.train")
            mode=input()
            if mode=="bus" or mode=="1":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                bus=input()
                if bus=="Ac" or bus=="1":
                    sum=sum+28000
                if bus=="Non Ac" or bus=="2":
                    sum=sum+20,900
            if mode=="train" or mode=="2":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                train=input()
                if train=="Ac" or train=="1":
                    sum=sum+29000
                if train=="Non Ac" or train=="2":
                    sum=sum+24080
        if place=="shimla" or place=="3":
            print("which mode of travelling you prefer:\n1.bus\n2.train")
            mode=input()
            if mode=="bus" or mode=="1":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                bus=input()
                if bus=="Ac" or bus=="1":
                    sum=sum+24000
                if bus=="Non Ac" or bus=="2":
                    sum=sum+19,000
            if mode=="train" or mode=="2":
                print("Do you prefer:\n1.Ac\n2.Non Ac")
                train=input()
                if train=="Ac" or train=="1":
                    sum=sum+26000
                if train=="Non Ac" or train=="2":
                    sum=sum+20,000
    print("you have to pay total of ",sum," for your trip mam/sir")
    print("which mode of pay will you prefer mam/sir?\ncredit card\ndebit card\ncash")
    pre=input()
    print("We will inform you the remaining details through mobile")
    print("thank you for visiting our agency")
    
tourism()    
